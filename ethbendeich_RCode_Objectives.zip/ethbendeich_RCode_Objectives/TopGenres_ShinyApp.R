# Set directory and open file
# INSERT FULL DIRECTORY CONTAINING CSV FILES FOR TITLES DATASETS
# USE THIS DIRECTORY AS AN EXAMPLE OF FORMATTING
setwd("C:/Users/ethbe/Downloads/ethbendeich_RCode_Objectives")
nf_df <- read.csv("netflix_titles.csv", header = TRUE, sep=",")
ap_df <- read.csv("amazon_prime_titles.csv", header = TRUE, sep=",")
dp_df <- read.csv("disney_plus_titles.csv", header = TRUE, sep=",")
hu_df <- read.csv("disney_plus_titles.csv", header = TRUE, sep=",")

# Install assets if needed
install.packages("wordcloud")
install.packages("stringr")
install.packages("plotly")
install.packages("shiny")



# Import necessary assets
library(wordcloud)
library(stringr)
library(plotly)
library(shiny)

# Get TV Shows and Movies into separate vectors fro the type column
nf_TV <- nf_df[nf_df$type == 'TV Show', ]
nf_movies <- nf_df[nf_df$type == 'Movie', ]
ap_TV <- ap_df[ap_df$type == 'TV Show', ]
ap_movies <- ap_df[ap_df$type == 'Movie', ]
dp_TV <- dp_df[dp_df$type == 'TV Show', ]
dp_movies <- dp_df[dp_df$type == 'Movie', ]
hu_TV <- hu_df[hu_df$type == 'TV Show', ]
hu_movies <- hu_df[hu_df$type == 'Movie', ]


# Get listed in values separated by movie and TV Shows
nf_TV_li <- nf_TV$listed_in
nf_movie_li <- nf_movies$listed_in

ap_TV_li <- ap_TV$listed_in
ap_movie_li <- ap_movies$listed_in

dp_TV_li <- dp_TV$listed_in
dp_movie_li <- dp_movies$listed_in

hu_TV_li <- hu_TV$listed_in
hu_movie_li <- hu_movies$listed_in


# Listed in vectors
nf_listed_in_TV_list <- c()
nf_listed_in_movie_list <- c()

ap_listed_in_TV_list <- c()
ap_listed_in_movie_list <- c()

dp_listed_in_TV_list <- c()
dp_listed_in_movie_list <- c()

hu_listed_in_TV_list <- c()
hu_listed_in_movie_list <- c()

# Get all individual genre values into listed in vectors for both TV Shows and movies
# NETFLIX
for (value in nf_TV_li) {
  temp_vec <- str_split(value, ", ", n = Inf, simplify = FALSE)
  for (split_value in temp_vec) {
    nf_listed_in_TV_list <- append(nf_listed_in_TV_list, split_value)
  }
}
for (value in nf_movie_li) {
  temp_vec <- str_split(value, ", ", n = Inf, simplify = FALSE)
  for (split_value in temp_vec) {
    nf_listed_in_movie_list <- append(nf_listed_in_movie_list, split_value)
  }
}
# AMAZON PRIME VIDEO
for (value in ap_TV_li) {
  temp_vec <- str_split(value, ", ", n = Inf, simplify = FALSE)
  for (split_value in temp_vec) {
    ap_listed_in_TV_list <- append(ap_listed_in_TV_list, split_value)
  }
}
for (value in ap_movie_li) {
  temp_vec <- str_split(value, ", ", n = Inf, simplify = FALSE)
  for (split_value in temp_vec) {
    ap_listed_in_movie_list <- append(ap_listed_in_movie_list, split_value)
  }
}
# DISNEY PLUS
for (value in dp_TV_li) {
  temp_vec <- str_split(value, ", ", n = Inf, simplify = FALSE)
  for (split_value in temp_vec) {
    dp_listed_in_TV_list <- append(dp_listed_in_TV_list, split_value)
  }
}

for (value in dp_movie_li) {
  temp_vec <- str_split(value, ", ", n = Inf, simplify = FALSE)
  for (split_value in temp_vec) {
    dp_listed_in_movie_list <- append(dp_listed_in_movie_list, split_value)
  }
}
# HULU
for (value in hu_TV_li) {
  temp_vec <- str_split(value, ", ", n = Inf, simplify = FALSE)
  for (split_value in temp_vec) {
    hu_listed_in_TV_list <- append(hu_listed_in_TV_list, split_value)
  }
}

for (value in hu_movie_li) {
  temp_vec <- str_split(value, ", ", n = Inf, simplify = FALSE)
  for (split_value in temp_vec) {
    hu_listed_in_movie_list <- append(hu_listed_in_movie_list, split_value)
  }
}

# The genre "Arts, Entertainment, and Culture" cannot be properly seperated by ", " a solution is the following:
# Replace all "and Culture" occurrences in the listed in vector with the full genre name.
# Remove all occurrences of "Arts" and "Entertainment from listed in vector
ap_listed_in_TV_list <- replace(ap_listed_in_TV_list, ap_listed_in_TV_list == "and Culture", "Arts, Entertainment, and Culture")
ap_listed_in_TV_list <- ap_listed_in_TV_list[! ap_listed_in_TV_list %in% c("Arts", "Entertainment")]

ap_listed_in_movie_list <- replace(ap_listed_in_movie_list, ap_listed_in_movie_list == "and Culture", "Arts, Entertainment, and Culture")
ap_listed_in_movie_list <- ap_listed_in_movie_list[! ap_listed_in_movie_list %in% c("Arts", "Entertainment")]





# Turn listed in vectors into frequency table, listing each genre and their frequency of occurrence
# Sort by decreasing
nf_listed_in_TV_list.freq = table(nf_listed_in_TV_list)
nf_sorted_TV <- nf_listed_in_TV_list.freq[order(nf_listed_in_TV_list.freq, decreasing = TRUE)]

nf_listed_in_movie_list.freq = table(nf_listed_in_movie_list)
nf_sorted_movie <- nf_listed_in_movie_list.freq[order(nf_listed_in_movie_list.freq, decreasing = TRUE)]

ap_listed_in_TV_list.freq = table(ap_listed_in_TV_list)
ap_sorted_TV <- ap_listed_in_TV_list.freq[order(ap_listed_in_TV_list.freq, decreasing = TRUE)]

ap_listed_in_movie_list.freq = table(ap_listed_in_movie_list)
ap_sorted_movie <- ap_listed_in_movie_list.freq[order(ap_listed_in_movie_list.freq, decreasing = TRUE)]

dp_listed_in_TV_list.freq = table(dp_listed_in_TV_list)
dp_sorted_TV <- dp_listed_in_TV_list.freq[order(dp_listed_in_TV_list.freq, decreasing = TRUE)]

dp_listed_in_movie_list.freq = table(dp_listed_in_movie_list)
dp_sorted_movie <- dp_listed_in_movie_list.freq[order(dp_listed_in_movie_list.freq, decreasing = TRUE)]

hu_listed_in_TV_list.freq = table(hu_listed_in_TV_list)
hu_sorted_TV <- hu_listed_in_TV_list.freq[order(hu_listed_in_TV_list.freq, decreasing = TRUE)]

hu_listed_in_movie_list.freq = table(hu_listed_in_movie_list)
hu_sorted_movie <- hu_listed_in_movie_list.freq[order(hu_listed_in_movie_list.freq, decreasing = TRUE)]



# Turn frequency tables into DataFrames
nf_li_TV_df <- data.frame(nf_sorted_TV)
nf_li_movie_df <- data.frame(nf_sorted_movie)

ap_li_TV_df <- data.frame(ap_sorted_TV)
ap_li_movie_df <- data.frame(ap_sorted_movie)

dp_li_TV_df <- data.frame(dp_sorted_TV)
dp_li_movie_df <- data.frame(dp_sorted_movie)

hu_li_TV_df <- data.frame(hu_sorted_TV)
hu_li_movie_df <- data.frame(hu_sorted_movie)


# Color palette for wordcloud and pie chart
nf_colfunc_TV <- colorRampPalette(c("#ff0000", "#ffbf00"))
nf_colfunc_movie <- colorRampPalette(c("#fc0000", "#707070"))

ap_colfunc_TV <- colorRampPalette(c("#00ffc8", "#dd00ff"))
ap_colfunc_movie <- colorRampPalette(c("#008f8a", "#64008f"))

dp_colfunc_TV <- colorRampPalette(c("#0062ff", "#54575c"))
dp_colfunc_movie <- colorRampPalette(c("#0d00ff", "#3decff"))

hu_colfunc_TV <- colorRampPalette(c("#00de1a", "#00de9f"))
hu_colfunc_movie <- colorRampPalette(c("#008c1e", "#008c8c"))

# Get top 10 highest occurring genres, get the sum of the frequency of the genres below the top 10
# Concatenate that to the top 10 occurring genres as a data frame, labeling the other frequency sum as "other"

# NETFLIX
nf_top_TV_li <- nf_li_TV_df[1:10,]

nf_top_TV_shows <- as.character(nf_top_TV_li$nf_listed_in_TV_list)
nf_top_TV_shows.freq <- nf_top_TV_li$Freq

nf_other_TV_li <- nf_li_TV_df[11:length(nf_li_TV_df$nf_listed_in_TV_list),]
nf_other_TV_shows.freq <- nf_other_TV_li$Freq
nf_other_TV_sum <- sum(nf_other_TV_shows.freq)

nf_listed_in_TV_list <- append(nf_top_TV_shows, "Other")
Freq <- append(nf_top_TV_shows.freq, nf_other_TV_sum)
nf_top_TV_li <- data.frame(nf_listed_in_TV_list, Freq)

nf_top_movie_li <- nf_li_movie_df[1:10,]

nf_top_movie <- as.character(nf_top_movie_li$nf_listed_in_movie_list)
nf_top_movie.freq <- nf_top_movie_li$Freq

nf_other_movie_li <- nf_li_movie_df[11:length(nf_li_movie_df$nf_listed_in_movie_list),]
nf_other_movie.freq <- nf_other_movie_li$Freq
nf_other_movie_sum <- sum(nf_other_movie.freq)

nf_listed_in_movie_list <- append(nf_top_TV_shows, "Other")
Freq <- append(nf_top_movie.freq, nf_other_movie_sum)
nf_top_movie_li <- data.frame(nf_listed_in_movie_list, Freq)

# AMAZON PRIME VIDEO
ap_top_TV_li <- ap_li_TV_df[1:10,]

ap_top_TV_shows <- as.character(ap_top_TV_li$ap_listed_in_TV_list)
ap_top_TV_shows.freq <- ap_top_TV_li$Freq

ap_other_TV_li <- ap_li_TV_df[11:length(ap_li_TV_df$ap_listed_in_TV_list),]
ap_other_TV_shows.freq <- ap_other_TV_li$Freq
ap_other_TV_sum <- sum(ap_other_TV_shows.freq)

ap_listed_in_TV_list <- append(ap_top_TV_shows, "Other")
Freq <- append(ap_top_TV_shows.freq, ap_other_TV_sum)
ap_top_TV_li <- data.frame(ap_listed_in_TV_list, Freq)

ap_top_movie_li <- ap_li_movie_df[1:10,]

ap_top_movie <- as.character(ap_top_movie_li$ap_listed_in_movie_list)
ap_top_movie.freq <- ap_top_movie_li$Freq

ap_other_movie_li <- ap_li_movie_df[11:length(ap_li_movie_df$ap_listed_in_movie_list),]
ap_other_movie.freq <- ap_other_movie_li$Freq
ap_other_movie_sum <- sum(ap_other_movie.freq)

ap_listed_in_movie_list <- append(ap_top_TV_shows, "Other")
Freq <- append(ap_top_movie.freq, ap_other_movie_sum)
ap_top_movie_li <- data.frame(ap_listed_in_movie_list, Freq)

# DISNEY PLUS

dp_top_TV_li <- dp_li_TV_df[1:10,]

dp_top_TV_shows <- as.character(dp_top_TV_li$dp_listed_in_TV_list)
dp_top_TV_shows.freq <- dp_top_TV_li$Freq

dp_other_TV_li <- dp_li_TV_df[11:length(dp_li_TV_df$dp_listed_in_TV_list),]
dp_other_TV_shows.freq <- dp_other_TV_li$Freq
dp_other_TV_sum <- sum(dp_other_TV_shows.freq)

dp_listed_in_TV_list <- append(dp_top_TV_shows, "Other")
Freq <- append(dp_top_TV_shows.freq, dp_other_TV_sum)
dp_top_TV_li <- data.frame(dp_listed_in_TV_list, Freq)

dp_top_movie_li <- dp_li_movie_df[1:10,]

dp_top_movie <- as.character(dp_top_movie_li$dp_listed_in_movie_list)
dp_top_movie.freq <- dp_top_movie_li$Freq

dp_other_movie_li <- dp_li_movie_df[11:length(dp_li_movie_df$dp_listed_in_movie_list),]
dp_other_movie.freq <- dp_other_movie_li$Freq
dp_other_movie_sum <- sum(dp_other_movie.freq)

dp_listed_in_movie_list <- append(dp_top_TV_shows, "Other")
Freq <- append(dp_top_movie.freq, dp_other_movie_sum)
dp_top_movie_li <- data.frame(dp_listed_in_movie_list, Freq)

# HULU

hu_top_TV_li <- hu_li_TV_df[1:10,]

hu_top_TV_shows <- as.character(hu_top_TV_li$hu_listed_in_TV_list)
hu_top_TV_shows.freq <- hu_top_TV_li$Freq

hu_other_TV_li <- hu_li_TV_df[11:length(hu_li_TV_df$hu_listed_in_TV_list),]
hu_other_TV_shows.freq <- hu_other_TV_li$Freq
hu_other_TV_sum <- sum(hu_other_TV_shows.freq)

hu_listed_in_TV_list <- append(hu_top_TV_shows, "Other")
Freq <- append(hu_top_TV_shows.freq, hu_other_TV_sum)
hu_top_TV_li <- data.frame(hu_listed_in_TV_list, Freq)

hu_top_movie_li <- hu_li_movie_df[1:10,]

hu_top_movie <- as.character(hu_top_movie_li$hu_listed_in_movie_list)
hu_top_movie.freq <- hu_top_movie_li$Freq

hu_other_movie_li <- hu_li_movie_df[11:length(hu_li_movie_df$hu_listed_in_movie_list),]
hu_other_movie.freq <- hu_other_movie_li$Freq
hu_other_movie_sum <- sum(hu_other_movie.freq)

hu_listed_in_movie_list <- append(hu_top_TV_shows, "Other")
Freq <- append(hu_top_movie.freq, hu_other_movie_sum)
hu_top_movie_li <- data.frame(hu_listed_in_movie_list, Freq)

# Plot Pie charts
# NETFLIX
nf_tv_pie <- plot_ly(nf_top_TV_li, labels = ~nf_listed_in_TV_list, values = ~Freq, type = 'pie',
                     textposition = 'inside',
                     textinfo = 'label+percent',
                     insidetextfont = list(color = "#FFFFFF"),
                     hoverinfo = "text",
                     text = ~paste(Freq, 'occurences'),
                     marker = list(colors = nf_colfunc_TV(11),
                                   line = list(color = '#FFFFFF', width = 1)),
                     showlegend = FALSE)

nf_tv_pie <- nf_tv_pie %>% layout(title = 'Top TV Show Genres Netflix',
                                  xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                                  yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))


nf_movie_pie <- plot_ly(nf_top_movie_li, labels = ~nf_listed_in_movie_list, values = ~Freq, type = 'pie',
                        textposition = 'inside',
                        textinfo = 'label+percent',
                        insidetextfont = list(color = "#FFFFFF"),
                        hoverinfo = "text",
                        text = ~paste(Freq, 'occurences'),
                        marker = list(colors = nf_colfunc_movie(11),
                                      line = list(color = '#FFFFFF', width = 1)),
                        showlegend = FALSE)

nf_movie_pie <- nf_movie_pie %>% layout(title = 'Top Movie Genres Netflix',
                                        xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                                        yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))

# AMAZON PRIME VIDEO
ap_tv_pie <- plot_ly(ap_top_TV_li, labels = ~ap_listed_in_TV_list, values = ~Freq, type = 'pie',
                     textposition = 'inside',
                     textinfo = 'label+percent',
                     insidetextfont = list(color = "#FFFFFF"),
                     hoverinfo = "text",
                     text = ~paste(Freq, 'occurences'),
                     marker = list(colors = ap_colfunc_TV(11),
                                   line = list(color = '#FFFFFF', width = 1)),
                     showlegend = FALSE)

ap_tv_pie <- ap_tv_pie %>% layout(title = 'Top TV Show Genres Amazon Prime',
                                  xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                                  yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))


ap_movie_pie <- plot_ly(ap_top_movie_li, labels = ~ap_listed_in_movie_list, values = ~Freq, type = 'pie',
                        textposition = 'inside',
                        textinfo = 'label+percent',
                        insidetextfont = list(color = "#FFFFFF"),
                        hoverinfo = "text",
                        text = ~paste(Freq, 'occurences'),
                        marker = list(colors = ap_colfunc_movie(11),
                                      line = list(color = '#FFFFFF', width = 1)),
                        showlegend = FALSE)

ap_movie_pie <- ap_movie_pie %>% layout(title = 'Top Movie Genres Amazon Prime',
                                        xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                                        yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))

# DISNEY PLUS
dp_tv_pie <- plot_ly(dp_top_TV_li, labels = ~dp_listed_in_TV_list, values = ~Freq, type = 'pie',
                     textposition = 'inside',
                     textinfo = 'label+percent',
                     insidetextfont = list(color = "#FFFFFF"),
                     hoverinfo = "text",
                     text = ~paste(Freq, 'occurences'),
                     marker = list(colors = dp_colfunc_TV(11),
                                   line = list(color = '#FFFFFF', width = 1)),
                     showlegend = FALSE)

dp_tv_pie <- dp_tv_pie %>% layout(title = 'Top TV Show Genres Disney Plus',
                                  xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                                  yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))

dp_movie_pie <- plot_ly(dp_top_movie_li, labels = ~dp_listed_in_movie_list, values = ~Freq, type = 'pie',
                        textposition = 'inside',
                        textinfo = 'label+percent',
                        insidetextfont = list(color = "#FFFFFF"),
                        hoverinfo = "text",
                        text = ~paste(Freq, 'occurences'),
                        marker = list(colors = dp_colfunc_movie(11),
                                      line = list(color = '#FFFFFF', width = 1)),
                        showlegend = FALSE)

dp_movie_pie <- dp_movie_pie %>% layout(title = 'Top Movie Genres Disney Plus',
                                        xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                                        yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))

# HULU
hu_tv_pie <- plot_ly(hu_top_TV_li, labels = ~hu_listed_in_TV_list, values = ~Freq, type = 'pie',
                     textposition = 'inside',
                     textinfo = 'label+percent',
                     insidetextfont = list(color = "#FFFFFF"),
                     hoverinfo = "text",
                     text = ~paste(Freq, 'occurences'),
                     marker = list(colors = hu_colfunc_TV(11),
                                   line = list(color = '#FFFFFF', width = 1)),
                     showlegend = FALSE)

hu_tv_pie <- hu_tv_pie %>% layout(title = 'Top TV Show Genres Hulu',
                                  xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                                  yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))


hu_movie_pie <- plot_ly(hu_top_movie_li, labels = ~hu_listed_in_movie_list, values = ~Freq, type = 'pie',
                        textposition = 'inside',
                        textinfo = 'label+percent',
                        insidetextfont = list(color = "#FFFFFF"),
                        hoverinfo = "text",
                        text = ~paste(Freq, 'occurences'),
                        marker = list(colors = hu_colfunc_movie(11),
                                      line = list(color = '#FFFFFF', width = 1)),
                        showlegend = FALSE)

hu_movie_pie <- hu_movie_pie %>% layout(title = 'Top Movie Genres Hulu',
                                        xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                                        yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))


# --- SHINY APP ---

# Dropdown inputs
platforms = c("Netflix", "Disney Plus", "Amazon Prime", "Hulu")
default = c("Select Platform")
netflixPies = c("Netflix TV Shows", "Netflix Movies")
dpPies = c("Disney Plus TV Shows", "Disney Plus Movies")
apPies = c("Amazon Prime Video TV Shows", "Amazon Prime Video Movies")
huluPies = c("Hulu TV Shows", "Hulu Movies")

# Shiny App page inputs and output
ui <- fluidPage( 
  titlePanel("Top Genres by each Platform"), 
  sidebarLayout( 
    sidebarPanel(  # INPUTS  
      selectInput("platformInput",  
                  "Select Platform:", 
                  choices =platforms),
      selectInput("genreInput",  
                  "Select Genre:", 
                  choices = default)),
    mainPanel(  # OUTPUTS 
      plotlyOutput("pie")),
  ) 
) 
# Server function
server <- function(input, output, session){ 
  platform <- reactive(input$platformInput)
  pie_type <- reactive(input$genreInput)

  # Functions to output specific pie charts when called
  netflix_TV <- reactive({
    nf_tv_pie
  })
  netflix_movie <- reactive({
    nf_movie_pie
  })
  dp_TV <- reactive({
    dp_tv_pie
  })
  dp_move <- reactive({
    dp_movie_pie
  })
  ap_TV <- reactive({

    ap_tv_pie
  })
  ap_movie <- reactive({

    ap_movie_pie
  })
  hulu_TV <- reactive({
    hu_tv_pie
  })
  hulu_movie <- reactive({
    hu_movie_pie
  })
  # Observe change in platform input, change TV show/movie dropdown respectively
  observe({
    if (platform() == "Netflix") {
      updateSelectInput(session, "genreInput", choices = netflixPies)
    }
    if (platform() == "Disney Plus") {
      updateSelectInput(session, "genreInput", choices = dpPies)
    }
    if (platform() == "Amazon Prime") {
      updateSelectInput(session, "genreInput", choices = apPies)
    }
    if (platform() == "Hulu") {
      updateSelectInput(session, "genreInput", choices = huluPies)
    }
  })
  # Call pie chart functions when dropdown input changes
  graphInput <- reactive({
    switch(input$genreInput,
           "Netflix TV Shows" = netflix_TV(),
           "Netflix Movies" = netflix_movie(),
           "Disney Plus TV Shows" = dp_TV(),
           "Disney Plus Movies" = dp_movie(),
           "Amazon Prime Video TV Shows" = ap_TV(),
           "Amazon Prime Video Movies" = ap_movie(),
           "Hulu TV Shows" = hulu_TV(),
           "Hulu Movies" = hulu_movie()
    )
  })
  
  output$pie <- renderPlotly({
    graphInput()
  })
} 
shinyApp(ui = ui, server = server) 

library(wordcloud)
# WORD CLOUDS
# ----- Netflix -----
nf_TV_wordcloud <- wordcloud(words = nf_li_TV_df$nf_listed_in_TV_list, freq = nf_li_TV_df$Freq, min.freq = 1,
                             max.words = 200, random.order = FALSE, rot.per = 0.28,
                             colors=nf_colfunc_TV(10))

nf_movie_wordcloud <- wordcloud(words = nf_li_movie_df$nf_listed_in_movie_list, freq = nf_li_movie_df$Freq, min.freq = 1,
                                max.words = 200, random.order = FALSE, rot.per = 0.28,
                                colors=nf_colfunc_movie(10))


# ----- Disney Plus -----
dp_TV_wordcloud <- wordcloud(words = dp_li_TV_df$dp_listed_in_TV_list, freq = dp_li_TV_df$Freq, min.freq = 1,
                             max.words = 200, random.order = FALSE, rot.per = 0.28,
                             colors=dp_colfunc_TV(10))

dp_movie_wordcloud <- wordcloud(words = dp_li_movie_df$dp_listed_in_movie_list, freq = dp_li_movie_df$Freq, min.freq = 1,
                                max.words = 200, random.order = FALSE, rot.per = 0.28,
                                colors=dp_colfunc_movie(10))

# ----- Amazon Prime Video -----
ap_TV_wordcloud <- wordcloud(words = ap_li_TV_df$ap_listed_in_TV_list, freq = ap_li_TV_df$Freq, min.freq = 1,
                             max.words = 200, random.order = FALSE, rot.per = 0.28,
                             colors=ap_colfunc_TV(10))


ap_movie_wordcloud <- wordcloud(words = ap_li_movie_df$ap_listed_in_movie_list, freq = ap_li_movie_df$Freq, min.freq = 1,
                                max.words = 200, random.order = FALSE, rot.per = 0.28,
                                colors=ap_colfunc_movie(10))


# ----- Hulu ------
hu_TV_wordcloud <- wordcloud(words = hu_li_TV_df$hu_listed_in_TV_list, freq = hu_li_TV_df$Freq, min.freq = 1,
                             max.words = 200, random.order = FALSE, rot.per = 0.28,
                             colors=hu_colfunc_TV(10))


hu_movie_wordcloud <- wordcloud(words = hu_li_movie_df$hu_listed_in_movie_list, freq = hu_li_movie_df$Freq, min.freq = 1,
                                max.words = 200, random.order = FALSE, rot.per = 0.28,
                                colors=hu_colfunc_movie(10))


