# Set directory and open file
# INSERT FULL DIRECTORY CONTAINING CSV FILES FOR TITLES DATASETS
# USE THIS DIRECTORY AS AN EXAMPLE OF FORMATTING
setwd("C:/Users/ethbe/Downloads/ethbendeich_RCode_Objectives")

# Open file and retrieve TV Show instances
nf_df <- read.csv("netflix_titles.csv", header = TRUE, sep=",")
dp_df <- read.csv("disney_plus_titles.csv", header = TRUE, sep=",")
ap_df <- read.csv("amazon_prime_titles.csv", header = TRUE, sep=",")
hu_df <- read.csv("hulu_titles.csv", header = TRUE, sep=",")

nf_TV <- nf_df[nf_df$type == 'TV Show', ]
dp_TV <- dp_df[dp_df$type == 'TV Show', ]
ap_TV <- ap_df[ap_df$type == 'TV Show', ]
hu_TV <- hu_df[hu_df$type == 'TV Show', ]

# Get titles and season duration
nf_shows <- nf_TV$title
nf_seasons <- nf_TV$duration

dp_shows <- dp_TV$title
dp_seasons <- dp_TV$duration

ap_shows <- ap_TV$title
ap_seasons <- ap_TV$duration

hu_shows <- hu_TV$title
hu_seasons <- hu_TV$duration

# Retrieve number from seasons for each instance 
nf_season_no <- c()
dp_season_no <- c()
ap_season_no <- c()
hu_season_no <- c()
for (value in nf_seasons) {
  nf_season_no <- append(nf_season_no, substr(value, 1, 1))
}
for (value in dp_seasons) {
  dp_season_no <- append(dp_season_no, substr(value, 1, 1))
}
for (value in ap_seasons) {
  ap_season_no <- append(ap_season_no, substr(value, 1, 1))
}
for (value in hu_seasons) {
  hu_season_no <- append(hu_season_no, substr(value, 1, 1))
}

nf_TV_shows_seasons <- data.frame(nf_shows,nf_season_no)
nf_TV_shows_seasons <- transform(nf_TV_shows_seasons, nf_season_no = as.numeric(nf_season_no))
dp_TV_shows_seasons <- data.frame(dp_shows,dp_season_no)
dp_TV_shows_seasons <- transform(dp_TV_shows_seasons, dp_season_no = as.numeric(dp_season_no))
ap_TV_shows_seasons <- data.frame(ap_shows,ap_season_no)
ap_TV_shows_seasons <- transform(ap_TV_shows_seasons, ap_season_no = as.numeric(ap_season_no))
hu_TV_shows_seasons <- data.frame(hu_shows,hu_season_no)
hu_TV_shows_seasons <- transform(hu_TV_shows_seasons, hu_season_no = as.numeric(hu_season_no))


# Get mean of all season number instances
nf_mean_seasons <- mean(nf_TV_shows_seasons$nf_season_no)
dp_mean_seasons <- mean(dp_TV_shows_seasons$dp_season_no)
ap_mean_seasons <- mean(ap_TV_shows_seasons$ap_season_no)
hu_mean_seasons <- mean(hu_TV_shows_seasons$hu_season_no)


# Print All
nf_mean_seasons
dp_mean_seasons
ap_mean_seasons
hu_mean_seasons



# --- SHINY APP ---
# Dropdown vectors
platforms <- c("Netflix", "Disney Plus", "Prime Video", "Hulu")
sortingOrder <- c("Longest to Shortest Shows", "Shortest to Longest Shows") 

install.packages("shiny")
install.packages("plotly")

library(shiny)
library(plotly)


# Page Layout
ui <- fluidPage( 
  
  titlePanel("Longest/Shortest Shows (by Season)"), 
  sidebarLayout( 
    sidebarPanel(  # INPUTS  
      selectInput("platformInput",  
                  "Select Platform:", 
                  choices = platforms),
      selectInput("sortInput",  
                  "Select Sorting Order:", 
                  choices = sortingOrder),
      sliderInput("showNumberInput", "Number of Shows:",  
                  value=5, min = 5,  
                  max = 5, step = 5)), 
    mainPanel(
      plotlyOutput("showHist")
    ) 
  ) 
)

library(plotly)
# Server Function
server <- function(session, input, output){
  platformInput <- reactive(input$platformInput)
  sortInput <- reactive(input$sortInput)
  showNum <- reactive(input$showNumberInput)
  
  # Observe function monitoring dropdown and slider input changes
  # If the platform dropdown changes, change to the corresponding platform selected
  # If the sorting dropdown changes, change the order of the selected platform graph 
  # Create corresponding graph when the specific conditions are met. 
  observe({
    output$showHist <- renderPlotly({
      if (platformInput() == "Netflix") {
        updateSliderInput(session, "showNumberInput", max = length(nf_TV_shows_seasons$nf_shows))
        if (sortInput() == "Longest to Shortest Shows") {
          nf_TV_shows_seasons <- nf_TV_shows_seasons[order(nf_TV_shows_seasons$nf_season_no, decreasing = TRUE),]
          x <- nf_TV_shows_seasons$nf_season_no[1:showNum()]
          y <- nf_TV_shows_seasons$nf_shows[1:showNum()]
          nf_bar_desc <- plot_ly() %>%
            add_trace(type = "bar",
                      orientation = "h",
                      x = x,
                      y = y,
                      text = ~paste(x, 'Seasons'),
                      marker = list(color = "rgb(255, 0, 0)")) %>%
            layout(title = "TV Show Duration (By Season)",
                   height = 750,
                   xaxis = list(title = "Seasons"),
                   yaxis = list(title = "TV Show", categoryorder = "total ascending"))
          nf_bar_desc
        }
        else {
          nf_TV_shows_seasons <- nf_TV_shows_seasons[order(nf_TV_shows_seasons$nf_season_no, decreasing = FALSE),]
          x <- nf_TV_shows_seasons$nf_season_no[1:showNum()]
          y <- nf_TV_shows_seasons$nf_shows[1:showNum()]
          nf_bar_asc <- plot_ly() %>%
            add_trace(type = "bar",
                      x = x,
                      y = y,
                      orientation = "h",
                      text = ~paste(x, 'Seasons'),
                      marker = list(color = "rgb(255, 0, 0)")) %>%
            layout(title = "TV Show Duration (By Season)",
                   height = 750,
                   xaxis = list(title = "Seasons"),
                   yaxis = list(title = "TV Shows", categoryorder = "total descending"))
          nf_bar_asc
        }
      }
      else if (platformInput() == "Disney Plus") {
        updateSliderInput(session, "showNumberInput", max = length(dp_TV_shows_seasons$dp_shows))
        if (sortInput() == "Longest to Shortest Shows") {
          dp_TV_shows_seasons <- dp_TV_shows_seasons[order(dp_TV_shows_seasons$dp_season_no, decreasing = TRUE),]
          x <- dp_TV_shows_seasons$dp_season_no[1:showNum()]
          y <- dp_TV_shows_seasons$dp_shows[1:showNum()]
          dp_bar_desc <- plot_ly() %>%
            add_trace(type = "bar",
                      orientation = "h",
                      x = x,
                      y = y,
                      text = ~paste(x, 'Seasons'),
                      marker = list(color = "rgb(11, 0, 161)")) %>%
            layout(title = "TV Show Duration (By Season)",
                   height = 750,
                   xaxis = list(title = "Seasons"),
                   yaxis = list(title = "TV Show", categoryorder = "total ascending"))
          dp_bar_desc
        }
        else {
          dp_TV_shows_seasons <- dp_TV_shows_seasons[order(dp_TV_shows_seasons$dp_season_no, decreasing = FALSE),]
          x <- dp_TV_shows_seasons$dp_season_no[1:showNum()]
          y <- dp_TV_shows_seasons$dp_shows[1:showNum()]
          dp_bar_asc <- plot_ly() %>%
            add_trace(type = "bar",
                      x = x,
                      y = y,
                      orientation = "h",
                      text = ~paste(x, 'Seasons'),
                      marker = list(color = "rgb(11, 0, 161)")) %>%
            layout(title = "TV Show Duration (By Season)",
                   height = 750,
                   xaxis = list(title = "Seasons"),
                   yaxis = list(title = "TV Shows", categoryorder = "total descending"))
          dp_bar_asc
        }
      }
      else if (platformInput() == "Prime Video") {
        updateSliderInput(session, "showNumberInput", max = length(ap_TV_shows_seasons$ap_shows))
        if (sortInput() == "Longest to Shortest Shows") {
          ap_TV_shows_seasons <- ap_TV_shows_seasons[order(ap_TV_shows_seasons$ap_season_no, decreasing = TRUE),]
          x <- ap_TV_shows_seasons$ap_season_no[1:showNum()]
          y <- ap_TV_shows_seasons$ap_shows[1:showNum()]
          ap_bar_desc <- plot_ly() %>%
            add_trace(type = "bar",
                      orientation = "h",
                      x = x,
                      y = y,
                      text = ~paste(x, 'Seasons'),
                      marker = list(color = "rgb(0, 237, 245)")) %>%
            layout(title = "TV Show Duration (By Season)",
                   height = 750,
                   xaxis = list(title = "Seasons"),
                   yaxis = list(title = "TV Show", categoryorder = "total ascending"))
          ap_bar_desc
        }
        else {
          ap_TV_shows_seasons <- ap_TV_shows_seasons[order(ap_TV_shows_seasons$ap_season_no, decreasing = FALSE),]
          x <- ap_TV_shows_seasons$ap_season_no[1:showNum()]
          y <- ap_TV_shows_seasons$ap_shows[1:showNum()]
          ap_bar_asc <- plot_ly() %>%
            add_trace(type = "bar",
                      x = x,
                      y = y,
                      orientation = "h",
                      text = ~paste(x, 'Seasons'),
                      marker = list(color = "rgb(0, 237, 245)")) %>%
            layout(title = "TV Show Duration (By Season)",
                   height = 750,
                   xaxis = list(title = "Seasons"),
                   yaxis = list(title = "TV Shows", categoryorder = "total descending"))
          ap_bar_asc
        }
      }
      else if (platformInput() == "Hulu") {
        updateSliderInput(session, "showNumberInput", max = length(ap_TV_shows_seasons$ap_shows))
        if (sortInput() == "Longest to Shortest Shows") {
          hu_TV_shows_seasons <- hu_TV_shows_seasons[order(hu_TV_shows_seasons$hu_season_no, decreasing = TRUE),]
          x <- hu_TV_shows_seasons$hu_season_no[1:showNum()]
          y <- hu_TV_shows_seasons$hu_shows[1:showNum()]
          hu_bar_desc <- plot_ly() %>%
            add_trace(type = "bar",
                      orientation = "h",
                      x = x,
                      y = y,
                      text = ~paste(x, 'Seasons'),
                      marker = list(color = "rgb(0, 227, 26)")) %>%
            layout(title = "TV Show Duration (By Season)",
                   height = 750,
                   xaxis = list(title = "Seasons"),
                   yaxis = list(title = "TV Show", categoryorder = "total ascending"))
          hu_bar_desc
        }
        else {
          hu_TV_shows_seasons <- hu_TV_shows_seasons[order(hu_TV_shows_seasons$hu_season_no, decreasing = FALSE),]
          x <- hu_TV_shows_seasons$hu_season_no[1:showNum()]
          y <- hu_TV_shows_seasons$hu_shows[1:showNum()]
          hu_bar_asc <- plot_ly() %>%
            add_trace(type = "bar",
                      x = x,
                      y = y,
                      orientation = "h",
                      text = ~paste(x, 'Seasons'),
                      marker = list(color = "rgb(0, 227, 26)")) %>%
            layout(title = "TV Show Duration (By Season)",
                   height = 750,
                   xaxis = list(title = "Seasons"),
                   yaxis = list(title = "TV Shows", categoryorder = "total descending"))
          hu_bar_asc
        }
      }
    })
  })
  
} 

shinyApp(ui = ui, server = server) 

