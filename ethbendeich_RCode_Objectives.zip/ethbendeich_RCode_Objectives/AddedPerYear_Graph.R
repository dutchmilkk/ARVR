# Set directory and open file
# INSERT FULL DIRECTORY CONTAINING CSV FILES FOR TITLES DATASETS
# USE THIS DIRECTORY AS AN EXAMPLE OF FORMATTING
setwd("C:/Users/ethbe/Downloads/ethbendeich_RCode_Objectives")
ap_df <- read.csv("amazon_prime_titles.csv", header = TRUE, sep=",")
dp_df <- read.csv("disney_plus_titles.csv", header = TRUE, sep=",")
nf_df <- read.csv("netflix_titles.csv", header = TRUE, sep=",")
hu_df <- read.csv("hulu_titles.csv", header = TRUE, sep=",")

# Retrieve TV Show instances from dataset
ap_TV <- ap_df[ap_df$type == 'TV Show', ]
dp_TV <- dp_df[dp_df$type == 'TV Show', ]
nf_TV <- nf_df[nf_df$type == 'TV Show', ]
hu_TV <- hu_df[hu_df$type == 'TV Show', ]

# Install assets if needed
install.packages("stringr")
install.packages("plotly")
install.packages("shiny")


library(plotly)
library(stringr)

# Retrive date vector from dataset
ap_datesAdded_raw <- ap_TV$date_added
dp_datesAdded_raw <- dp_TV$date_added
nf_datesAdded_raw <- nf_TV$date_added
hu_datesAdded_raw <- hu_TV$date_added

# Remove empty date instances
ap_datesAdded <- ap_datesAdded_raw[!ap_datesAdded_raw %in% ""]
dp_datesAdded <- dp_datesAdded_raw[!dp_datesAdded_raw %in% ""]
nf_datesAdded <- nf_datesAdded_raw[!nf_datesAdded_raw %in% ""]
hu_datesAdded <- hu_datesAdded_raw[!hu_datesAdded_raw %in% ""]

# Split date in half and add to vector
ap_splitDates <- c()
dp_splitDates <- c()
nf_splitDates <- c()
hu_splitDates <- c()

for (value in ap_datesAdded) {
  split_value <- str_split(value, ", ", n = Inf, simplify = FALSE)
  ap_splitDates <- append(ap_splitDates, split_value)
}
for (value in dp_datesAdded) {
  split_value <- str_split(value, ", ", n = Inf, simplify = FALSE)
  dp_splitDates <- append(dp_splitDates, split_value)
}
for (value in nf_datesAdded) {
  split_value <- str_split(value, ", ", n = Inf, simplify = FALSE)
  nf_splitDates <- append(nf_splitDates, split_value)
}
for (value in hu_datesAdded) {
  split_value <- str_split(value, ", ", n = Inf, simplify = FALSE)
  hu_splitDates <- append(hu_splitDates, split_value)
}

# Retrieve year from each split date
ap_years <- c()
dp_years <- c()
nf_years <- c()
hu_years <- c()
for (value in ap_splitDates) {
  ap_years <- append(ap_years, value[2])
}
for (value in dp_splitDates) {
  dp_years <- append(dp_years, value[2])
}
for (value in nf_splitDates) {
  nf_years <- append(nf_years, value[2])
}
for (value in hu_splitDates) {
  hu_years <- append(hu_years, value[2])
}
dp_showsAdded_perYear <- data.frame(table(dp_years))
ap_showsAdded_perYear <- data.frame(table(ap_years))
nf_showsAdded_perYear <- data.frame(table(nf_years))
hu_showsAdded_perYear <- data.frame(table(hu_years))

# Print Amazon Prime Table (only one year is present which is 2021)
View(ap_showsAdded_perYear)

# Plot Line Graph
library(plotly)
fig <- plot_ly(type = 'scatter', mode = 'lines')
fig <- fig %>% layout(title = "Shows added per year", xaxis = list(title = "Year"), yaxis = list(title = "Shows Added"))
fig <- fig %>% add_trace(data = nf_showsAdded_perYear, x = ~nf_years, y = ~Freq, name = "Netflix", line = list(color = "rgb(255, 0, 0)"))
fig <- fig %>% add_trace(data = dp_showsAdded_perYear, x = ~dp_years, y = ~Freq, name = "Disney Plus", line = list(color = "rgb(11, 0, 161)"))
fig <- fig %>% add_trace(data = hu_showsAdded_perYear, x = ~hu_years, y = ~Freq, name = "Hulu", line = list(color = "rgb(0, 227, 26)"))

fig
