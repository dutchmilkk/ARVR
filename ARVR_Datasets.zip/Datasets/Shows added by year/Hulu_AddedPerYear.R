setwd("C:/Users/ethbe/Downloads/Datasets")
hu_df <- read.csv("hulu_titles.csv", header = TRUE, sep=",")


# Retrieve TV Show instances from dataset
hu_TV <- hu_df[hu_df$type == 'TV Show', ]

library(plotly)
library(stringr)


# Retrive date vector from dataset
hu_datesAdded_raw <- hu_TV$date_added

# Remove empty date instances
hu_datesAdded <- hu_datesAdded_raw[!hu_datesAdded_raw %in% ""]


# Split date in half and add to vector
hu_splitDates <- c()

for (value in hu_datesAdded) {
  split_value <- str_split(value, ", ", n = Inf, simplify = FALSE)
  hu_splitDates <- append(hu_splitDates, split_value)
}


# Retrieve year from each split date
hu_years <- c()
for (value in hu_splitDates) {
  hu_years <- append(hu_years, value[2])
}
hu_years <- as.character(hu_years)

hu_showsAdded_perYear <- data.frame(table(hu_years))