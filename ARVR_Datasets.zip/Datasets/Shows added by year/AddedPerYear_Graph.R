library(plotly)
fig <- plot_ly(type = 'scatter', mode = 'lines')
fig <- fig %>% layout(title = "Shows added per year", xaxis = list(title = "Year"), yaxis = list(title = "Shows Added"))
fig <- fig %>% add_trace(data = nf_showsAdded_perYear, x = ~nf_years, y = ~Freq, name = "Netflix", line = list(color = "rgb(255, 0, 0)"))
fig <- fig %>% add_trace(data = dp_showsAdded_perYear, x = ~dp_years, y = ~Freq, name = "Disney Plus", line = list(color = "rgb(11, 0, 161)"))
fig <- fig %>% add_trace(data = hu_showsAdded_perYear, x = ~hu_years, y = ~Freq, name = "Hulu", line = list(color = "rgb(0, 227, 26)"))

fig