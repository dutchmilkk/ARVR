setwd("C:/Users/ethbe/Downloads/Datasets")
nf_df <- read.csv("netflix_titles.csv", header = TRUE, sep=",")


# Retrieve TV Show instances from dataset
nf_TV <- nf_df[nf_df$type == 'TV Show', ]

library(plotly)
library(stringr)


# Retrive date vector from dataset
nf_datesAdded_raw <- nf_TV$date_added

# Remove empty date instances
nf_datesAdded <- nf_datesAdded_raw[!nf_datesAdded_raw %in% ""]


# Split date in half and add to vector
nf_splitDates <- c()

for (value in nf_datesAdded) {
  split_value <- str_split(value, ", ", n = Inf, simplify = FALSE)
  nf_splitDates <- append(nf_splitDates, split_value)
}


# Retrieve year from each split date
nf_years <- c()

for (value in nf_splitDates) {
  nf_years <- append(nf_years, value[2])
}

nf_showsAdded_perYear <- data.frame(table(nf_years))
