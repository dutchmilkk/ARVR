setwd("C:/Users/ethbe/Downloads/Datasets")
ap_df <- read.csv("amazon_prime_titles.csv", header = TRUE, sep=",")

# Retrieve TV Show instances from dataset
ap_TV <- ap_df[ap_df$type == 'TV Show', ]


library(plotly)
library(stringr)

# Retrive date vector from dataset
ap_datesAdded_raw <- ap_TV$date_added

# Remove empty date instances
ap_datesAdded <- ap_datesAdded_raw[!ap_datesAdded_raw %in% ""]

# Split date in half and add to vector
ap_splitDates <- c()
for (value in ap_datesAdded) {
  split_value <- str_split(value, ", ", n = Inf, simplify = FALSE)
  ap_splitDates <- append(ap_splitDates, split_value)
}

# Retrieve year from each split date
ap_years <- c()
for (value in ap_splitDates) {
  ap_years <- append(ap_years, value[2])
}

#
ap_years <- as.character(ap_years)
ap_showsAdded_perYear <- data.frame(table(ap_years))


# Print Table (only one year is present which is 2021)
View(ap_showsAdded_perYear)
