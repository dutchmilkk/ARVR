setwd("C:/Users/ethbe/Downloads/Datasets")
dp_df <- read.csv("disney_plus_titles.csv", header = TRUE, sep=",")


# Retrieve TV Show instances from dataset
dp_TV <- dp_df[dp_df$type == 'TV Show', ]

library(plotly)
library(stringr)


# Retrive date vector from dataset
dp_datesAdded_raw <- dp_TV$date_added

# Remove empty date instances
dp_datesAdded <- dp_datesAdded_raw[!dp_datesAdded_raw %in% ""]


# Split date in half and add to vector
dp_splitDates <- c()

for (value in dp_datesAdded) {
  split_value <- str_split(value, ", ", n = Inf, simplify = FALSE)
  dp_splitDates <- append(dp_splitDates, split_value)
}

# Retrieve year from each split date
dp_years <- c()

for (value in dp_splitDates) {
  dp_years <- append(dp_years, value[2])
}

dp_showsAdded_perYear <- data.frame(table(dp_years))
