Please compile all of:
disneyPlus_AddedPerYear
Netflix_AddedPerYear
primeVideo_AddedPerYear
Hulu_AddedPerYear

Before compiling all of:
AddedPerYear_Graph
