Please compile all of:
amazonPrime_TVShow_seasons
disneyPlus_TVShow_seasons
hulu_TVShow_seasons
netflix_TVShow_seasons

Before compiling all of:
Seasons_Binge
Seasons_ShinyApp
