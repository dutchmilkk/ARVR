# Set directory and open file
# INSERT FULL DIRECTORY CONTAINING CSV FILES FOR NETFLIX TITLES DATASET
# USE THIS DIRECTORY AS AN EXAMPLE OF FORMATTING
setwd("C:/Users/ethbe/Downloads/Datasets")


# Open file and retrieve TV Show instances
nf_df <- read.csv("netflix_titles.csv", header = TRUE, sep=",")
nf_TV <- nf_df[nf_df$type == 'TV Show', ]


# Get titles and season duration
nf_shows <- nf_TV$title
nf_seasons <- nf_TV$duration


# Retrieve number from seasons for each instance 
nf_season_no <- c()
for (value in nf_seasons) {
  nf_season_no <- append(nf_season_no, substr(value, 1, 1))
}
nf_TV_shows_seasons <- data.frame(nf_shows,nf_season_no)
nf_TV_shows_seasons <- transform(nf_TV_shows_seasons, nf_season_no = as.numeric(nf_season_no))

