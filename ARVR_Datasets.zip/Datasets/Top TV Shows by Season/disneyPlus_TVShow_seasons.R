# Set directory and open file
# INSERT FULL DIRECTORY CONTAINING CSV FILES FOR DISNEY PLUS TITLES DATASET
# USE THIS DIRECTORY AS AN EXAMPLE OF FORMATTING
setwd("C:/Users/ethbe/Downloads/Datasets")

# Open file and retrieve TV Show instances
dp_df <- read.csv("disney_plus_titles.csv", header = TRUE, sep=",")
dp_TV <- dp_df[dp_df$type == 'TV Show', ]

# Get titles and season duration
dp_shows <- dp_TV$title
dp_seasons <- dp_TV$duration


# Retrieve number from seasons for each instance 
dp_season_no <- c()
for (value in dp_seasons) {
  dp_season_no <- append(dp_season_no, substr(value, 1, 1))
}


dp_TV_shows_seasons <- data.frame(dp_shows,dp_season_no)
dp_TV_shows_seasons <- transform(dp_TV_shows_seasons, dp_season_no = as.numeric(dp_season_no))
