# Set directory and open file
# INSERT FULL DIRECTORY CONTAINING CSV FILES FOR HULU TITLES DATASET
# USE THIS DIRECTORY AS AN EXAMPLE OF FORMATTING
setwd("C:/Users/ethbe/Downloads/Datasets")

# Open file and retrieve TV Show instances
hu_df <- read.csv("hulu_titles.csv", header = TRUE, sep=",")
hu_TV <- hu_df[hu_df$type == 'TV Show', ]

# Get titles and season duration
hu_shows <- hu_TV$title
hu_seasons <- hu_TV$duration


# Retrieve number from seasons for each instance 
hu_season_no <- c()
for (value in hu_seasons) {
  hu_season_no <- append(hu_season_no, substr(value, 1, 1))
}


hu_TV_shows_seasons <- data.frame(hu_shows,hu_season_no)
hu_TV_shows_seasons <- transform(hu_TV_shows_seasons, hu_season_no = as.numeric(hu_season_no))