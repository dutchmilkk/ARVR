library(plotly)


# Get mean of all season number instances
nf_mean_seasons <- mean(nf_TV_shows_seasons$nf_season_no)
dp_mean_seasons <- mean(dp_TV_shows_seasons$dp_season_no)
ap_mean_seasons <- mean(ap_TV_shows_seasons$ap_season_no)
hu_mean_seasons <- mean(hu_TV_shows_seasons$hu_season_no)


# Print All
nf_mean_seasons
dp_mean_seasons
ap_mean_seasons
hu_mean_seasons
