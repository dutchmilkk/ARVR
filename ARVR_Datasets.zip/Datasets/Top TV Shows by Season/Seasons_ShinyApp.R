# Dropdown vectors
platforms <- c("Netflix", "Disney Plus", "Prime Video", "Hulu")
sortingOrder <- c("Longest to Shortest Shows", "Shortest to Longest Shows") 

library(shiny)
install.packages("shinyWidges")


# Page Layout
ui <- fluidPage( 
  
  titlePanel("Longest/Shortest Shows (by Season)"), 
  sidebarLayout( 
    sidebarPanel(  # INPUTS  
      selectInput("platformInput",  
                  "Select Platform:", 
                  choices = platforms),
      selectInput("sortInput",  
                  "Select Sorting Order:", 
                  choices = sortingOrder),
      sliderInput("showNumberInput", "Number of Shows:",  
                  value=5, min = 5,  
                  max = 5, step = 5)), 
    mainPanel(
      plotlyOutput("showHist")
    ) 
  ) 
)


# Server Function
server <- function(session, input, output){
  platformInput <- reactive(input$platformInput)
  sortInput <- reactive(input$sortInput)
  showNum <- reactive(input$showNumberInput)
  
  # Observe function monitoring dropdown and slider input changes
  # If the platform dropdown changes, change to the corresponding platform selected
  # If the sorting dropdown changes, change the order of the selected platform graph 
  # Create corresponding graph when the specific conditions are met. 
  observe({
    output$showHist <- renderPlotly({
      if (platformInput() == "Netflix") {
        updateSliderInput(session, "showNumberInput", max = length(nf_TV_shows_seasons$nf_shows))
        if (sortInput() == "Longest to Shortest Shows") {
          nf_TV_shows_seasons <- nf_TV_shows_seasons[order(nf_TV_shows_seasons$nf_season_no, decreasing = TRUE),]
          y <- nf_TV_shows_seasons$nf_season_no[1:showNum()]
          x <- nf_TV_shows_seasons$nf_shows[1:showNum()]
          nf_bar_desc <- plot_ly() %>%
            add_trace(type = "bar",
                      x = x,
                      y = y,
                      marker = list(color = "rgb(255, 0, 0)")) %>%
            layout(title = "TV Show Duration (By Season)",
                   xaxis = list(title = "TV Show", categoryorder = "total descending"),
                   yaxis = list(title = "Seasons"))
          nf_bar_desc
        }
        else {
          nf_TV_shows_seasons <- nf_TV_shows_seasons[order(nf_TV_shows_seasons$nf_season_no, decreasing = FALSE),]
          y <- nf_TV_shows_seasons$nf_season_no[1:showNum()]
          x <- nf_TV_shows_seasons$nf_shows[1:showNum()]
          nf_bar_asc <- plot_ly() %>%
            add_trace(type = "bar",
                      x = x,
                      y = y,
                      marker = list(color = "rgb(255, 0, 0)")) %>%
            layout(title = "TV Show Duration (By Season)",
                   xaxis = list(title = "TV Show", categoryorder = "total ascending"),
                   yaxis = list(title = "Seasons"))
          nf_bar_asc
        }
      }
      else if (platformInput() == "Disney Plus") {
        updateSliderInput(session, "showNumberInput", max = length(dp_TV_shows_seasons$dp_shows))
        if (sortInput() == "Longest to Shortest Shows") {
          dp_TV_shows_seasons <- dp_TV_shows_seasons[order(dp_TV_shows_seasons$dp_season_no, decreasing = TRUE),]
          y <- dp_TV_shows_seasons$dp_season_no[1:showNum()]
          x <- dp_TV_shows_seasons$dp_shows[1:showNum()]
          dp_bar_desc <- plot_ly() %>%
            add_trace(type = "bar",
                      x = x,
                      y = y,
                      marker = list(color = "rgb(11, 0, 161)")) %>%
            layout(title = "TV Show Duration (By Season)",
                   xaxis = list(title = "TV Show", categoryorder = "total descending"),
                   yaxis = list(title = "Seasons"))
          dp_bar_desc
        }
        else {
          dp_TV_shows_seasons <- dp_TV_shows_seasons[order(dp_TV_shows_seasons$dp_season_no, decreasing = FALSE),]
          y <- dp_TV_shows_seasons$dp_season_no[1:showNum()]
          x <- dp_TV_shows_seasons$dp_shows[1:showNum()]
          dp_bar_asc <- plot_ly() %>%
            add_trace(type = "bar",
                      x = x,
                      y = y,
                      marker = list(color = "rgb(11, 0, 161)")) %>%
            layout(title = "TV Show Duration (By Season)",
                   xaxis = list(title = "TV Show", categoryorder = "total ascending"),
                   yaxis = list(title = "Seasons"))
          dp_bar_asc
        }
      }
      else if (platformInput() == "Prime Video") {
        updateSliderInput(session, "showNumberInput", max = length(ap_TV_shows_seasons$ap_shows))
        if (sortInput() == "Longest to Shortest Shows") {
          ap_TV_shows_seasons <- ap_TV_shows_seasons[order(ap_TV_shows_seasons$ap_season_no, decreasing = TRUE),]
          y <- ap_TV_shows_seasons$ap_season_no[1:showNum()]
          x <- ap_TV_shows_seasons$ap_shows[1:showNum()]
          ap_bar_desc <- plot_ly() %>%
            add_trace(type = "bar",
                      x = x,
                      y = y,
                      marker = list(color = "rgb(0, 187, 255)")) %>%
            layout(title = "TV Show Duration (By Season)",
                   xaxis = list(title = "TV Show", categoryorder = "total descending"),
                   yaxis = list(title = "Seasons"))
          ap_bar_desc
        }
        else {
          ap_TV_shows_seasons <- ap_TV_shows_seasons[order(ap_TV_shows_seasons$ap_season_no, decreasing = FALSE),]
          y <- ap_TV_shows_seasons$ap_season_no[1:showNum()]
          x <- ap_TV_shows_seasons$ap_shows[1:showNum()]
          ap_bar_asc <- plot_ly() %>%
            add_trace(type = "bar",
                      x = x,
                      y = y,
                      marker = list(color = "rgb(0, 187, 255)")) %>%
            layout(title = "TV Show Duration (By Season)",
                   xaxis = list(title = "TV Show", categoryorder = "total ascending"),
                   yaxis = list(title = "Seasons"))
          ap_bar_asc
        }
      }
      else if (platformInput() == "Hulu") {
        updateSliderInput(session, "showNumberInput", max = length(ap_TV_shows_seasons$ap_shows))
        if (sortInput() == "Longest to Shortest Shows") {
          hu_TV_shows_seasons <- hu_TV_shows_seasons[order(hu_TV_shows_seasons$hu_season_no, decreasing = TRUE),]
          y <- hu_TV_shows_seasons$hu_season_no[1:showNum()]
          x <- hu_TV_shows_seasons$hu_shows[1:showNum()]
          hu_bar_desc <- plot_ly() %>%
            add_trace(type = "bar",
                      x = x,
                      y = y,
                      marker = list(color = "rgb(0, 227, 26)")) %>%
            layout(title = "TV Show Duration (By Season)",
                   xaxis = list(title = "TV Show", categoryorder = "total descending"),
                   yaxis = list(title = "Seasons"))
          hu_bar_desc
        }
        else {
          hu_TV_shows_seasons <- hu_TV_shows_seasons[order(hu_TV_shows_seasons$hu_season_no, decreasing = FALSE),]
          y <- hu_TV_shows_seasons$hu_season_no[1:showNum()]
          x <- hu_TV_shows_seasons$hu_shows[1:showNum()]
          hu_bar_asc <- plot_ly() %>%
            add_trace(type = "bar",
                      x = x,
                      y = y,
                      marker = list(color = "rgb(0, 227, 26)")) %>%
            layout(title = "TV Show Duration (By Season)",
                   xaxis = list(title = "TV Show", categoryorder = "total ascending"),
                   yaxis = list(title = "Seasons"))
          hu_bar_asc
        }
      }
    })
  })
  
} 

shinyApp(ui = ui, server = server) 

