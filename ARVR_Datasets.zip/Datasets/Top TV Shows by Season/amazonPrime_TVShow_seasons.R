# Set directory and open file
# INSERT FULL DIRECTORY CONTAINING CSV FILES FOR AMAZON PRIME TITLES DATASET
# USE THIS DIRECTORY AS AN EXAMPLE OF FORMATTING
setwd("C:/Users/ethbe/Downloads/Datasets")


# Open file and retrieve TV Show instances
ap_df <- read.csv("amazon_prime_titles.csv", header = TRUE, sep=",")
ap_TV <- ap_df[ap_df$type == 'TV Show', ]

# Get titles and season duration
ap_shows <- ap_TV$title
ap_seasons <- ap_TV$duration


# Retrieve number from seasons for each instance 
ap_season_no <- c()
for (value in ap_seasons) {
  ap_season_no <- append(ap_season_no, substr(value, 1, 1))
}


ap_TV_shows_seasons <- data.frame(ap_shows,ap_season_no)
ap_TV_shows_seasons <- transform(ap_TV_shows_seasons, ap_season_no = as.numeric(ap_season_no))