# Set directory and open file
# INSERT FULL DIRECTORY CONTAINING CSV FILES FOR HULU TITLES DATASET
# USE THIS DIRECTORY AS AN EXAMPLE OF FORMATTING
setwd("C:/Users/ethbe/Downloads/Datasets")
hu_df <- read.csv("disney_plus_titles.csv", header = TRUE, sep=",")


# Import necessary assets
library(wordcloud)
library(RColorBrewer)


library(stringr)
library(MASS)
library(plotly)

# Get TV Shows and Movies into separate vectors fro the type column
hu_TV <- hu_df[hu_df$type == 'TV Show', ]
hu_movies <- hu_df[hu_df$type == 'Movie', ]


# Get listed in values separated by movie and TV Shows
hu_TV_li <- hu_TV$listed_in
hu_movie_li <- hu_movies$listed_in


# Listed in vectors
hu_listed_in_TV_list <- c()
hu_listed_in_movie_list <- c()


# Get all individual genre values into listed in vectors for both TV Shows and movies
for (value in hu_TV_li) {
  temp_vec <- str_split(value, ", ", n = Inf, simplify = FALSE)
  for (split_value in temp_vec) {
    hu_listed_in_TV_list <- append(hu_listed_in_TV_list, split_value)
  }
}

for (value in hu_movie_li) {
  temp_vec <- str_split(value, ", ", n = Inf, simplify = FALSE)
  for (split_value in temp_vec) {
    hu_listed_in_movie_list <- append(hu_listed_in_movie_list, split_value)
  }
}

# Turn listed in vectors into frequency table, listing each genre and their frequency of occurrence
# Sort by decreasing
hu_listed_in_TV_list.freq = table(hu_listed_in_TV_list)
hu_sorted_TV <- hu_listed_in_TV_list.freq[order(hu_listed_in_TV_list.freq, decreasing = TRUE)]

hu_listed_in_movie_list.freq = table(hu_listed_in_movie_list)
hu_sorted_movie <- hu_listed_in_movie_list.freq[order(hu_listed_in_movie_list.freq, decreasing = TRUE)]

# Turn frequency tables into DataFrames
hu_li_TV_df <- data.frame(hu_sorted_TV)
hu_li_movie_df <- data.frame(hu_sorted_movie)


# Color palette for wordcloud and pie chart
hu_colfunc_TV <- colorRampPalette(c("#00de1a", "#00de9f"))
hu_colfunc_movie <- colorRampPalette(c("#008c1e", "#008c8c"))


# Get top 10 highest occurring genres, get the sum of the frequency of the genres below the top 10
# Concatenate that to the top 10 occurring genres as a data frame, labeling the other frequency sum as "other"
hu_top_TV_li <- hu_li_TV_df[1:10,]

hu_top_TV_shows <- as.character(hu_top_TV_li$hu_listed_in_TV_list)
hu_top_TV_shows.freq <- hu_top_TV_li$Freq

hu_other_TV_li <- hu_li_TV_df[11:length(hu_li_TV_df$hu_listed_in_TV_list),]
hu_other_TV_shows.freq <- hu_other_TV_li$Freq
hu_other_TV_sum <- sum(hu_other_TV_shows.freq)

hu_listed_in_TV_list <- append(hu_top_TV_shows, "Other")
Freq <- append(hu_top_TV_shows.freq, hu_other_TV_sum)
hu_top_TV_li <- data.frame(hu_listed_in_TV_list, Freq)

hu_top_movie_li <- hu_li_movie_df[1:10,]

hu_top_movie <- as.character(hu_top_movie_li$hu_listed_in_movie_list)
hu_top_movie.freq <- hu_top_movie_li$Freq

hu_other_movie_li <- hu_li_movie_df[11:length(hu_li_movie_df$hu_listed_in_movie_list),]
hu_other_movie.freq <- hu_other_movie_li$Freq
hu_other_movie_sum <- sum(hu_other_movie.freq)

hu_listed_in_movie_list <- append(hu_top_TV_shows, "Other")
Freq <- append(hu_top_movie.freq, hu_other_movie_sum)
hu_top_movie_li <- data.frame(hu_listed_in_movie_list, Freq)

# Plot Pie charts
hu_tv_pie <- plot_ly(hu_top_TV_li, labels = ~hu_listed_in_TV_list, values = ~Freq, type = 'pie',
                     textposition = 'inside',
                     textinfo = 'label+percent',
                     insidetextfont = list(color = "#FFFFFF"),
                     hoverinfo = "text",
                     text = ~paste(Freq, 'occurences'),
                     marker = list(colors = hu_colfunc_TV(11),
                                   line = list(color = '#FFFFFF', width = 1)),
                     showlegend = FALSE)

hu_tv_pie <- hu_tv_pie %>% layout(title = 'Top TV Show Genres Hulu',
                                  xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                                  yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))


hu_movie_pie <- plot_ly(hu_top_movie_li, labels = ~hu_listed_in_movie_list, values = ~Freq, type = 'pie',
                        textposition = 'inside',
                        textinfo = 'label+percent',
                        insidetextfont = list(color = "#FFFFFF"),
                        hoverinfo = "text",
                        text = ~paste(Freq, 'occurences'),
                        marker = list(colors = hu_colfunc_movie(11),
                                      line = list(color = '#FFFFFF', width = 1)),
                        showlegend = FALSE)

hu_movie_pie <- hu_movie_pie %>% layout(title = 'Top Movie Genres Hulu',
                                        xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                                        yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
