library(wordcloud)


# ----- Netflix -----
nf_TV_wordcloud <- wordcloud(words = nf_li_TV_df$nf_listed_in_TV_list, freq = nf_li_TV_df$Freq, min.freq = 1,
          max.words = 200, random.order = FALSE, rot.per = 0.28,
          colors=nf_colfunc_TV(10))

nf_movie_wordcloud <- wordcloud(words = nf_li_movie_df$nf_listed_in_movie_list, freq = nf_li_movie_df$Freq, min.freq = 1,
          max.words = 200, random.order = FALSE, rot.per = 0.28,
          colors=nf_colfunc_movie(10))


# ----- Disney Plus -----
dp_TV_wordcloud <- wordcloud(words = dp_li_TV_df$dp_listed_in_TV_list, freq = dp_li_TV_df$Freq, min.freq = 1,
          max.words = 200, random.order = FALSE, rot.per = 0.28,
          colors=dp_colfunc_TV(10))

dp_movie_wordcloud <- wordcloud(words = dp_li_movie_df$dp_listed_in_movie_list, freq = dp_li_movie_df$Freq, min.freq = 1,
          max.words = 200, random.order = FALSE, rot.per = 0.28,
          colors=dp_colfunc_movie(10))

# ----- Amazon Prime Video -----
ap_TV_wordcloud <- wordcloud(words = ap_li_TV_df$ap_listed_in_TV_list, freq = ap_li_TV_df$Freq, min.freq = 1,
          max.words = 200, random.order = FALSE, rot.per = 0.28,
          colors=ap_colfunc_TV(10))


ap_movie_wordcloud <- wordcloud(words = ap_li_movie_df$ap_listed_in_movie_list, freq = ap_li_movie_df$Freq, min.freq = 1,
          max.words = 200, random.order = FALSE, rot.per = 0.28,
          colors=ap_colfunc_movie(10))


# ----- Hulu ------
hu_TV_wordcloud <- wordcloud(words = hu_li_TV_df$hu_listed_in_TV_list, freq = hu_li_TV_df$Freq, min.freq = 1,
          max.words = 200, random.order = FALSE, rot.per = 0.28,
          colors=hu_colfunc_TV(10))


hu_movie_wordcloud <- wordcloud(words = hu_li_movie_df$hu_listed_in_movie_list, freq = hu_li_movie_df$Freq, min.freq = 1,
          max.words = 200, random.order = FALSE, rot.per = 0.28,
          colors=hu_colfunc_movie(10))
