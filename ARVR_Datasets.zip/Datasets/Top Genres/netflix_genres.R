# Set directory and open file
# INSERT FULL DIRECTORY CONTAINING CSV FILES FOR NETFLIX TITLES DATASET
# USE THIS DIRECTORY AS AN EXAMPLE OF FORMATTING
setwd("C:/Users/ethbe/Downloads/Datasets")
nf_df <- read.csv("netflix_titles.csv", header = TRUE, sep=",")


# Import necessary assets
library(wordcloud)
library(stringr)
library(MASS)
library(plotly)
library(shiny)

# Get TV Shows and Movies into separate vectors fro the type column
nf_TV <- nf_df[nf_df$type == 'TV Show', ]
nf_movies <- nf_df[nf_df$type == 'Movie', ]


# Get listed in values separated by movie and TV Shows
nf_TV_li <- nf_TV$listed_in
nf_movie_li <- nf_movies$listed_in


# Listed in vectors
nf_listed_in_TV_list <- c()
nf_listed_in_movie_list <- c()

# Get all individual genre values into listed in vectors for both TV Shows and movies
for (value in nf_TV_li) {
  temp_vec <- str_split(value, ", ", n = Inf, simplify = FALSE)
  for (split_value in temp_vec) {
    nf_listed_in_TV_list <- append(nf_listed_in_TV_list, split_value)
  }
}
for (value in nf_movie_li) {
  temp_vec <- str_split(value, ", ", n = Inf, simplify = FALSE)
  for (split_value in temp_vec) {
    nf_listed_in_movie_list <- append(nf_listed_in_movie_list, split_value)
  }
}



# Turn listed in vectors into frequency table, listing each genre and their frequency of occurrence
# Sort by decreasing
nf_listed_in_TV_list.freq = table(nf_listed_in_TV_list)
nf_sorted_TV <- nf_listed_in_TV_list.freq[order(nf_listed_in_TV_list.freq, decreasing = TRUE)]

nf_listed_in_movie_list.freq = table(nf_listed_in_movie_list)
nf_sorted_movie <- nf_listed_in_movie_list.freq[order(nf_listed_in_movie_list.freq, decreasing = TRUE)]


# Turn frequency tables into DataFrames
nf_li_TV_df <- data.frame(nf_sorted_TV)
nf_li_movie_df <- data.frame(nf_sorted_movie)


# Color palette for wordcloud and pie chart
nf_colfunc_TV <- colorRampPalette(c("#ff0000", "#ffbf00"))
nf_colfunc_movie <- colorRampPalette(c("#fc0000", "#707070"))



# Get top 10 highest occurring genres, get the sum of the frequency of the genres below the top 10
# Concatenate that to the top 10 occurring genres as a data frame, labeling the other frequency sum as "other"
nf_top_TV_li <- nf_li_TV_df[1:10,]

nf_top_TV_shows <- as.character(nf_top_TV_li$nf_listed_in_TV_list)
nf_top_TV_shows.freq <- nf_top_TV_li$Freq

nf_other_TV_li <- nf_li_TV_df[11:length(nf_li_TV_df$nf_listed_in_TV_list),]
nf_other_TV_shows.freq <- nf_other_TV_li$Freq
nf_other_TV_sum <- sum(nf_other_TV_shows.freq)

nf_listed_in_TV_list <- append(nf_top_TV_shows, "Other")
Freq <- append(nf_top_TV_shows.freq, nf_other_TV_sum)
nf_top_TV_li <- data.frame(nf_listed_in_TV_list, Freq)

nf_top_movie_li <- nf_li_movie_df[1:10,]

nf_top_movie <- as.character(nf_top_movie_li$nf_listed_in_movie_list)
nf_top_movie.freq <- nf_top_movie_li$Freq

nf_other_movie_li <- nf_li_movie_df[11:length(nf_li_movie_df$nf_listed_in_movie_list),]
nf_other_movie.freq <- nf_other_movie_li$Freq
nf_other_movie_sum <- sum(nf_other_movie.freq)

nf_listed_in_movie_list <- append(nf_top_TV_shows, "Other")
Freq <- append(nf_top_movie.freq, nf_other_movie_sum)
nf_top_movie_li <- data.frame(nf_listed_in_movie_list, Freq)



# Plot Pie charts
nf_tv_pie <- plot_ly(nf_top_TV_li, labels = ~nf_listed_in_TV_list, values = ~Freq, type = 'pie',
               textposition = 'inside',
               textinfo = 'label+percent',
               insidetextfont = list(color = "#FFFFFF"),
               hoverinfo = "text",
               text = ~paste(Freq, 'occurences'),
               marker = list(colors = nf_colfunc_TV(11),
                             line = list(color = '#FFFFFF', width = 1)),
               showlegend = FALSE)

nf_tv_pie <- nf_tv_pie %>% layout(title = 'Top TV Show Genres Netflix',
                      xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                      yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))


nf_movie_pie <- plot_ly(nf_top_movie_li, labels = ~nf_listed_in_movie_list, values = ~Freq, type = 'pie',
                     textposition = 'inside',
                     textinfo = 'label+percent',
                     insidetextfont = list(color = "#FFFFFF"),
                     hoverinfo = "text",
                     text = ~paste(Freq, 'occurences'),
                     marker = list(colors = nf_colfunc_movie(11),
                                   line = list(color = '#FFFFFF', width = 1)),
                     showlegend = FALSE)

nf_movie_pie <- nf_movie_pie %>% layout(title = 'Top Movie Genres Netflix',
                                  xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                                  yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))




















