Please compile all of:
amazon_prime_genres
disney_plus_genres
hulu_genres
netflix_genres

Before compiling all of:
Wordclouds
TopGenres_ShinyApp