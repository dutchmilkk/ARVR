# Set directory and open file
# INSERT FULL DIRECTORY CONTAINING CSV FILES FOR DISNEY PLUS TITLES DATASET
# USE THIS DIRECTORY AS AN EXAMPLE OF FORMATTING
setwd("C:/Users/ethbe/Downloads/Datasets")
dp_df <- read.csv("disney_plus_titles.csv", header = TRUE, sep=",")


# Import necessary assets
library(wordcloud)
library(RColorBrewer)
library(wordcloud2)


library(stringr)
library(MASS)
library(plotly)


# Get TV Shows and Movies into separate vectors fro the type column
dp_TV <- dp_df[dp_df$type == 'TV Show', ]
dp_movies <- dp_df[dp_df$type == 'Movie', ]


# Get listed in values separated by movie and TV Shows
dp_TV_li <- dp_TV$listed_in
dp_movie_li <- dp_movies$listed_in


# Listed in vectors
dp_listed_in_TV_list <- c()
dp_listed_in_movie_list <- c()


# Get all individual genre values into listed in vectors for both TV Shows and movies

for (value in dp_TV_li) {
  temp_vec <- str_split(value, ", ", n = Inf, simplify = FALSE)
  for (split_value in temp_vec) {
    dp_listed_in_TV_list <- append(dp_listed_in_TV_list, split_value)
  }
}

for (value in dp_movie_li) {
  temp_vec <- str_split(value, ", ", n = Inf, simplify = FALSE)
  for (split_value in temp_vec) {
    dp_listed_in_movie_list <- append(dp_listed_in_movie_list, split_value)
  }
}

# Turn listed in vectors into frequency table, listing each genre and their frequency of occurrence
# Sort by decreasing
dp_listed_in_TV_list.freq = table(dp_listed_in_TV_list)
dp_sorted_TV <- dp_listed_in_TV_list.freq[order(dp_listed_in_TV_list.freq, decreasing = TRUE)]

dp_listed_in_movie_list.freq = table(dp_listed_in_movie_list)
dp_sorted_movie <- dp_listed_in_movie_list.freq[order(dp_listed_in_movie_list.freq, decreasing = TRUE)]

# Turn frequency tables into DataFrames
dp_li_TV_df <- data.frame(dp_sorted_TV)
dp_li_movie_df <- data.frame(dp_sorted_movie)

# Color palette for wordcloud and pie chart
dp_colfunc_TV <- colorRampPalette(c("#0062ff", "#54575c"))
dp_colfunc_movie <- colorRampPalette(c("#0d00ff", "#3decff"))

# Get top 10 highest occurring genres, get the sum of the frequency of the genres below the top 10
# Concatenate that to the top 10 occurring genres as a data frame, labeling the other frequency sum as "other"
dp_top_TV_li <- dp_li_TV_df[1:10,]

dp_top_TV_shows <- as.character(dp_top_TV_li$dp_listed_in_TV_list)
dp_top_TV_shows.freq <- dp_top_TV_li$Freq

dp_other_TV_li <- dp_li_TV_df[11:length(dp_li_TV_df$dp_listed_in_TV_list),]
dp_other_TV_shows.freq <- dp_other_TV_li$Freq
dp_other_TV_sum <- sum(dp_other_TV_shows.freq)

dp_listed_in_TV_list <- append(dp_top_TV_shows, "Other")
Freq <- append(dp_top_TV_shows.freq, dp_other_TV_sum)
dp_top_TV_li <- data.frame(dp_listed_in_TV_list, Freq)

dp_top_movie_li <- dp_li_movie_df[1:10,]

dp_top_movie <- as.character(dp_top_movie_li$dp_listed_in_movie_list)
dp_top_movie.freq <- dp_top_movie_li$Freq

dp_other_movie_li <- dp_li_movie_df[11:length(dp_li_movie_df$dp_listed_in_movie_list),]
dp_other_movie.freq <- dp_other_movie_li$Freq
dp_other_movie_sum <- sum(dp_other_movie.freq)

dp_listed_in_movie_list <- append(dp_top_TV_shows, "Other")
Freq <- append(dp_top_movie.freq, dp_other_movie_sum)
dp_top_movie_li <- data.frame(dp_listed_in_movie_list, Freq)


# Plot Pie charts
dp_tv_pie <- plot_ly(dp_top_TV_li, labels = ~dp_listed_in_TV_list, values = ~Freq, type = 'pie',
                     textposition = 'inside',
                     textinfo = 'label+percent',
                     insidetextfont = list(color = "#FFFFFF"),
                     hoverinfo = "text",
                     text = ~paste(Freq, 'occurences'),
                     marker = list(colors = dp_colfunc_TV(11),
                                   line = list(color = '#FFFFFF', width = 1)),
                     showlegend = FALSE)

dp_tv_pie <- dp_tv_pie %>% layout(title = 'Top TV Show Genres Disney Plus',
                                  xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                                  yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))

dp_movie_pie <- plot_ly(dp_top_movie_li, labels = ~dp_listed_in_movie_list, values = ~Freq, type = 'pie',
                        textposition = 'inside',
                        textinfo = 'label+percent',
                        insidetextfont = list(color = "#FFFFFF"),
                        hoverinfo = "text",
                        text = ~paste(Freq, 'occurences'),
                        marker = list(colors = dp_colfunc_movie(11),
                                      line = list(color = '#FFFFFF', width = 1)),
                        showlegend = FALSE)

dp_movie_pie <- dp_movie_pie %>% layout(title = 'Top Movie Genres Disney Plus',
                                        xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                                        yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
