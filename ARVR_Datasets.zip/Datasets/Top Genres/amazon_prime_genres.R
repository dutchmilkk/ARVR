# Set directory and open file
# INSERT FULL DIRECTORY CONTAINING CSV FILES FOR AMAZON PRIME TITLES DATASET
# USE THIS DIRECTORY AS AN EXAMPLE OF FORMATTING
setwd("C:/Users/ethbe/Downloads/Datasets")
ap_df <- read.csv("amazon_prime_titles.csv", header = TRUE, sep=",")

# Import necessary assets
library(wordcloud)
library(RColorBrewer)
library(wordcloud2)


library(stringr)
library(MASS)
library(plotly)

# Get TV Shows and Movies into separate vectors fro the type column
ap_TV <- ap_df[ap_df$type == 'TV Show', ]
ap_movies <- ap_df[ap_df$type == 'Movie', ]

# Get listed in values separated by movie and TV Shows
ap_TV_li <- ap_TV$listed_in
ap_movie_li <- ap_movies$listed_in

ap_listed_in_TV_list <- c()
ap_listed_in_movie_list <- c()


# Get all individual genre values into listed in vectors for both TV Shows and movies
for (value in ap_TV_li) {
  temp_vec <- str_split(value, ", ", n = Inf, simplify = FALSE)
  for (split_value in temp_vec) {
    ap_listed_in_TV_list <- append(ap_listed_in_TV_list, split_value)
  }
}

for (value in ap_movie_li) {
  temp_vec <- str_split(value, ", ", n = Inf, simplify = FALSE)
  for (split_value in temp_vec) {
    ap_listed_in_movie_list <- append(ap_listed_in_movie_list, split_value)
  }
}
# The genre "Arts, Entertainment, and Culture" cannot be properly seperated by ", " a solution is the following:
# Replace all "and Culture" occurrences in the listed in vector with the full genre name.
# Remove all occurrences of "Arts" and "Entertainment from listed in vector
ap_listed_in_TV_list <- replace(ap_listed_in_TV_list, ap_listed_in_TV_list == "and Culture", "Arts, Entertainment, and Culture")
ap_listed_in_TV_list <- ap_listed_in_TV_list[! ap_listed_in_TV_list %in% c("Arts", "Entertainment")]

ap_listed_in_movie_list <- replace(ap_listed_in_movie_list, ap_listed_in_movie_list == "and Culture", "Arts, Entertainment, and Culture")
ap_listed_in_movie_list <- ap_listed_in_movie_list[! ap_listed_in_movie_list %in% c("Arts", "Entertainment")]

# Turn listed in vectors into frequency table, listing each genre and their frequency of occurrence
# Sort by decreasing
ap_listed_in_TV_list.freq = table(ap_listed_in_TV_list)
ap_sorted_TV <- ap_listed_in_TV_list.freq[order(ap_listed_in_TV_list.freq, decreasing = TRUE)]

ap_listed_in_movie_list.freq = table(ap_listed_in_movie_list)
ap_sorted_movie <- ap_listed_in_movie_list.freq[order(ap_listed_in_movie_list.freq, decreasing = TRUE)]

# Turn frequency tables into DataFrames
ap_li_TV_df <- data.frame(ap_sorted_TV)
ap_li_movie_df <- data.frame(ap_sorted_movie)


# Color palette for wordcloud and pie chart
ap_colfunc_TV <- colorRampPalette(c("#00ffc8", "#dd00ff"))
ap_colfunc_movie <- colorRampPalette(c("#008f8a", "#64008f"))


# Get top 10 highest occurring genres, get the sum of the frequency of the genres below the top 10
# Concatenate that to the top 10 occurring genres as a data frame, labeling the other frequency sum as "other"
ap_top_TV_li <- ap_li_TV_df[1:10,]

ap_top_TV_shows <- as.character(ap_top_TV_li$ap_listed_in_TV_list)
ap_top_TV_shows.freq <- ap_top_TV_li$Freq

ap_other_TV_li <- ap_li_TV_df[11:length(ap_li_TV_df$ap_listed_in_TV_list),]
ap_other_TV_shows.freq <- ap_other_TV_li$Freq
ap_other_TV_sum <- sum(ap_other_TV_shows.freq)

ap_listed_in_TV_list <- append(ap_top_TV_shows, "Other")
Freq <- append(ap_top_TV_shows.freq, ap_other_TV_sum)
ap_top_TV_li <- data.frame(ap_listed_in_TV_list, Freq)

ap_top_movie_li <- ap_li_movie_df[1:10,]

ap_top_movie <- as.character(ap_top_movie_li$ap_listed_in_movie_list)
ap_top_movie.freq <- ap_top_movie_li$Freq

ap_other_movie_li <- ap_li_movie_df[11:length(ap_li_movie_df$ap_listed_in_movie_list),]
ap_other_movie.freq <- ap_other_movie_li$Freq
ap_other_movie_sum <- sum(ap_other_movie.freq)

ap_listed_in_movie_list <- append(ap_top_TV_shows, "Other")
Freq <- append(ap_top_movie.freq, ap_other_movie_sum)
ap_top_movie_li <- data.frame(ap_listed_in_movie_list, Freq)


# Plot Pie charts
ap_tv_pie <- plot_ly(ap_top_TV_li, labels = ~ap_listed_in_TV_list, values = ~Freq, type = 'pie',
                     textposition = 'inside',
                     textinfo = 'label+percent',
                     insidetextfont = list(color = "#FFFFFF"),
                     hoverinfo = "text",
                     text = ~paste(Freq, 'occurences'),
                     marker = list(colors = ap_colfunc_TV(11),
                                   line = list(color = '#FFFFFF', width = 1)),
                     showlegend = FALSE)

ap_tv_pie <- ap_tv_pie %>% layout(title = 'Top TV Show Genres Amazon Prime',
                                  xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                                  yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))


ap_movie_pie <- plot_ly(ap_top_movie_li, labels = ~ap_listed_in_movie_list, values = ~Freq, type = 'pie',
                        textposition = 'inside',
                        textinfo = 'label+percent',
                        insidetextfont = list(color = "#FFFFFF"),
                        hoverinfo = "text",
                        text = ~paste(Freq, 'occurences'),
                        marker = list(colors = ap_colfunc_movie(11),
                                      line = list(color = '#FFFFFF', width = 1)),
                        showlegend = FALSE)

ap_movie_pie <- ap_movie_pie %>% layout(title = 'Top Movie Genres Amazon Prime',
                                        xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                                        yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
