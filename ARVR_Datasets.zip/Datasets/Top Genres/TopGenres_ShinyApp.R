library(shiny)


# Dropdown inputs
platforms = c("Netflix", "Disney Plus", "Amazon Prime", "Hulu")
default = c("Select Platform")
netflixPies = c("Netflix TV Shows", "Netflix Movies")
dpPies = c("Disney Plus TV Shows", "Disney Plus Movies")
apPies = c("Amazon Prime Video TV Shows", "Amazon Prime Video Movies")
huluPies = c("Hulu TV Shows", "Hulu Movies")

# Shiny App page inputs and output
ui <- fluidPage( 
  titlePanel("Top Genres by each Platform"), 
  sidebarLayout( 
    sidebarPanel(  # INPUTS  
      selectInput("platformInput",  
                  "Select Platform:", 
                  choices =platforms),
      selectInput("genreInput",  
                  "Select Genre:", 
                  choices = default)),
    mainPanel(  # OUTPUTS 
      plotlyOutput("pie")),
  ) 
) 
# Server function
server <- function(input, output, session){ 
  platform <- reactive(input$platformInput)
  pie_type <- reactive(input$genreInput)

  # Functions to output specific pie charts when called
  netflix_TV <- reactive({
    nf_tv_pie
  })
  netflix_movie <- reactive({
    nf_movie_pie
  })
  dp_TV <- reactive({
    dp_tv_pie
  })
  dp_move <- reactive({
    dp_movie_pie
  })
  ap_TV <- reactive({

    ap_tv_pie
  })
  ap_movie <- reactive({

    ap_movie_pie
  })
  hulu_TV <- reactive({
    hu_tv_pie
  })
  hulu_movie <- reactive({
    hu_movie_pie
  })
  # Observe change in platform input, change TV show/movie dropdown respectively
  observe({
    if (platform() == "Netflix") {
      updateSelectInput(session, "genreInput", choices = netflixPies)
    }
    if (platform() == "Disney Plus") {
      updateSelectInput(session, "genreInput", choices = dpPies)
    }
    if (platform() == "Amazon Prime") {
      updateSelectInput(session, "genreInput", choices = apPies)
    }
    if (platform() == "Hulu") {
      updateSelectInput(session, "genreInput", choices = huluPies)
    }
  })
  # Call pie chart functions when dropdown input changes
  graphInput <- reactive({
    switch(input$genreInput,
           "Netflix TV Shows" = netflix_TV(),
           "Netflix Movies" = netflix_movie(),
           "Disney Plus TV Shows" = dp_TV(),
           "Disney Plus Movies" = dp_movie(),
           "Amazon Prime Video TV Shows" = ap_TV(),
           "Amazon Prime Video Movies" = ap_movie(),
           "Hulu TV Shows" = hulu_TV(),
           "Hulu Movies" = hulu_movie()
    )
  })
  
  output$pie <- renderPlotly({
    graphInput()
  })
} 
shinyApp(ui = ui, server = server) 
